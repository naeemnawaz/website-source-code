from django.urls import path

from . import views

app_name = 'home'

urlpatterns = [
    path('', views.home, name='home'),
    path('services/', views.services, name='services'),
    path('blog/', views.blog, name='blog'),
    path('contact/', views.contact, name='contact'),
    path('services/cloud/', views.cloud, name='cloud'),
    path('services/ai/', views.ai, name='ai'),
    path('services/app/', views.app, name='app'),
    path('services/iot/', views.iot, name='iot'),
    path('services/datan/', views.datan, name='datan'),
    path('product/', views.product, name='product'),
]
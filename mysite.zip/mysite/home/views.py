#from django.http import HttpResponse
from django.shortcuts import render
from home.models import message
from django.contrib import messages
def home(request):
    return render(request,"home/home.html")

def product(request):
    return render(request,"home/product.html")
def services(request):
    return render(request,"home/services.html")
def blog(request):
    return render(request,"home/blog.html")
def contact(request): 
    if request.method=='POST':
        name = request.POST['name']
        phone = request.POST['phone']
        email = request.POST['email']
        company = request.POST['company']
        subject = request.POST['subject']
        msg = request.POST['msg']
        data = message(name=name, email=email\
            ,phone=phone,company=company\
            ,subject=subject,msg=msg)
        data.save()
        messages.add_message(request, messages.INFO, 'your message is sent sccussfully')
        return render(request,"home/contact.html")
    return render(request,"home/contact.html")

def cloud(request):
    return render(request,"home/cloud.html")
def ai(request):
    return render(request,"home/ai.html")
def app(request):
    return render(request,"home/app.html")
def iot(request):
    return render(request,"home/iot.html")
def datan(request):
    return render(request,"home/datan.html")
#from django.http import HttpResponse
from django.shortcuts import render ,redirect
from django.contrib.auth.models import User,  auth
from accounts.models import signup
from django.contrib.auth import authenticate, login 

from django.contrib import messages


from django.contrib.auth import logout

def logout(request):
    auth.logout(request)
    return redirect('/')


def register(request):
    if request.method=='POST':
        if 'signup' in request.POST:
            username = request.POST['username']
            first_name = request.POST['firstname']
            last_name = request.POST['lastname']
            email = request.POST['email']
            password = request.POST['password']
            if User.objects.filter(username=username,password=password).exists():
                messages.add_message(request, messages.INFO, 'this username ID is already exists')
                return render(request,"accounts/login.html")
            else:
                try:
                    data = User(username=username,first_name=first_name,last_name=last_name,email=email,password=password)
                    data.set_password(password)
                    data.save()
                    print('user is created')
                    return render(request,"accounts/login.html")
                except Exception as e:
                    messages.add_message(request,messages.INFO,'this username ID is already exists')
                    return render(request,"accounts/login.html")

            
        elif 'login' in request.POST:
            username = request.POST['username']
            password = request.POST['password']
            val = authenticate(username=username, password=password)
            if val is not None:
                print("this si error")
                login(request, val)
                return redirect("/")
            else:
                messages.add_message(request, messages.INFO, 'invalid username and password')
                return render(request,"accounts/login.html")
            return render(request,"accounts/login.html")
        else:
            return render(request,"accounts/login.html")
    else:
        return render(request,"accounts/login.html")

"""
        if emailpass and passwordpass is not None:
            if signup.objects.filter(email=email,password=password).exists():
                User = signup.objects.filter(email=email, password=password)
                if User is not None:
                    #auth.login(request,User)
                    print('the user is authenticated sccessfully')
                    return redirect("accounts/login.html")
                else:
                    print("wrong password or username")
                    return render(request,"accounts/login.html")
            else:
                print("wrong password or emai")
                return render(request,"accounts/login.html")
        
        else:
            data = signup(username=username, company=company,email=email,password=password)
            data.save()
            print('user is created')
        
            return render(request,"accounts/login.html")
    else:
        return render(request,"accounts/login.html")
"""


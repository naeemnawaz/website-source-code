from django.db import models

class signup(models.Model):
    username = models.CharField(max_length=50 , unique=True)
    company = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    password1 = models.CharField(max_length=50)

    class Meta:
        pass
    """permissions = [
        ("change_task_status", "Can change the status of tasks"),
        ("close_task", "Can remove a task by setting its status as closed"),
"""
